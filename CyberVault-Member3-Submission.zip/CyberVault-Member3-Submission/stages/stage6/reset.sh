#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

for file in auth.log deploy_history.txt incident-note.txt incident-token.txt; do
    if [[ ! -f "baseline/$file" ]]; then
        echo "Error: baseline/$file not found."
        exit 1
    fi
done

cp baseline/auth.log evidence/auth.log
cp baseline/deploy_history.txt evidence/deploy_history.txt
cp baseline/incident-note.txt evidence/incident-note.txt
cp baseline/incident-token.txt evidence/incident-token.txt

echo "Stage 6 evidence restored to baseline."
