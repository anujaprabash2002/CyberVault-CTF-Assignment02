# CyberVault CTF — Stage 6: The Compromised Server

## Scenario

You are a security analyst investigating suspicious activity on a Linux server named `vault-server`. Your task is to investigate SSH authentication events, identify the compromised account, and correlate the activity with suspicious service and deployment evidence.

The challenge is designed around an Ubuntu Server VM with SSH access. The provided log files are supplementary training evidence and do not replace the live server investigation.

## Case Information

* Case ID: CV-606
* Host: vault-server
* Category: Linux Server Forensics
* Difficulty: Intermediate
* Points: 400
* Flag format: `CVCTF{...}`

## Player Objectives

1. Connect to the designated Ubuntu Server VM using the authorized SSH credentials provided by the challenge administrator.
2. Examine SSH authentication logs and identify suspicious login attempts.
3. Identify the suspicious source IP and the account accessed.
4. Investigate the designated simulated suspicious service and correlate its activity with the incident.
5. Review the deployment history and incident notes.
6. Decode the recovered incident token to obtain the flag.

## Provided Supplementary Evidence

* `auth.log` — simulated SSH authentication and sudo activity.
* `deploy_history.txt` — simulated shell history for the deployment account.
* `incident-note.txt` — investigation notes and evidence reference.
* `incident-token.txt` — Base64-encoded incident token.

These files provide a reproducible evidence trail for the challenge. They are simulated and must not be presented as logs collected from a real compromised server.

## Suggested Tools

* `ssh` for authorized access to the Ubuntu Server VM.
* `journalctl` and the relevant authentication log for reviewing login events.
* `systemctl` and `ss` for examining the designated suspicious service and listening ports.
* `cat` and `grep` for inspecting text evidence.
* `base64` for decoding the incident token.

Only investigate the designated training VM and services.

## Hints

1. Compare failed and successful SSH authentication events.
2. Check whether the same source IP appears in multiple events.
3. Look for activity following the successful login.
4. Correlate the service and deployment evidence with the authentication timeline.
5. Follow the incident note to the encoded token and identify its encoding.

## Submission

Submit the recovered flag through the CTF platform's flag submission field.

Expected format: `CVCTF{...}`

## Training Notice

All supplied log files are simulated for educational use. The live Ubuntu Server VM and suspicious service must be configured and tested separately before this stage is described as fully deployed.
