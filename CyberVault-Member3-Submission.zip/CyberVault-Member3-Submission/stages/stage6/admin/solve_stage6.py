#!/usr/bin/env python3

import base64
import re
import sys
from pathlib import Path


def solve(evidence_dir):
    evidence_dir = Path(evidence_dir).resolve()

    required = [
        "auth.log",
        "deploy_history.txt",
        "incident-note.txt",
        "incident-token.txt",
    ]

    for name in required:
        if not (evidence_dir / name).is_file():
            raise FileNotFoundError(f"Missing evidence file: {name}")

    # Step 1: Correlate SSH failures and successful logins.
    auth_log = (evidence_dir / "auth.log").read_text(encoding="utf-8")

    failures = re.findall(
        r"Failed password for .*? from (\d+\.\d+\.\d+\.\d+)", auth_log
    )
    successes = re.findall(
        r"Accepted password for (\S+) from (\d+\.\d+\.\d+\.\d+)", auth_log
    )

    suspicious_ip = next(
        (ip for ip in failures if any(ip == success_ip for _, success_ip in successes)),
        None,
    )
    if not suspicious_ip:
        raise ValueError("Could not correlate failed and successful SSH logins.")

    account = next(
        (user for user, ip in successes if ip == suspicious_ip), None
    )
    if not account:
        raise ValueError("No successful login found for the suspicious IP.")

    print(f"[1] Suspicious source IP: {suspicious_ip}")
    print(f"[2] Successful account from that IP: {account}")

    # Step 2: Check the recovered shell history.
    history = (evidence_dir / "deploy_history.txt").read_text(encoding="utf-8")
    if "find /var/backups -type f" not in history:
        raise ValueError("Expected backup-directory investigation not found.")
    print("[3] Shell history confirms investigation of /var/backups")

    # Step 3: Follow the incident note to the token.
    note = (evidence_dir / "incident-note.txt").read_text(encoding="utf-8")
    if "incident-token.txt" not in note or "encoded" not in note.lower():
        raise ValueError("Incident note does not identify the encoded token.")
    print("[4] Incident note points to the encoded incident token")

    # Step 4: Decode and validate the recovered flag.
    token = (evidence_dir / "incident-token.txt").read_text(encoding="utf-8").strip()
    decoded = base64.b64decode(token, validate=True).decode("utf-8")

    if not re.fullmatch(r"CVCTF\{[A-Za-z0-9_!-]+\}", decoded):
        raise ValueError("Decoded token is not in the expected flag format.")

    print(f"[5] Recovered flag: {decoded}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <player-evidence-directory>")
        sys.exit(2)

    try:
        solve(sys.argv[1])
    except (OSError, ValueError) as error:
        print(f"Solver error: {error}", file=sys.stderr)
        sys.exit(1)
