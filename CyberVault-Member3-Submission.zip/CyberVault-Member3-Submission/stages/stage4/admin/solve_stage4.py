#!/usr/bin/env python3

import re
import subprocess
import sys
import zipfile
from pathlib import Path
from io import BytesIO


def solve(evidence_dir):
    evidence_dir = Path(evidence_dir).resolve()
    image = evidence_dir / "IMG_204.jpg"

    if not image.is_file():
        raise FileNotFoundError(f"Image not found: {image}")

    # 1. Inspect the JPEG metadata.
    result = subprocess.run(
        ["exiftool", "-s3", "-UserComment", str(image)],
        capture_output=True,
        text=True,
        check=True,
    )
    clue = result.stdout.strip()
    print(f"[1] Metadata clue: {clue}")

    match = re.search(r"stored in ([A-Za-z0-9_.-]+)", clue)
    if not match:
        raise ValueError("Case-note filename not found in metadata.")

    note_name = match.group(1)
    note_path = evidence_dir / note_name

    if not note_path.is_file():
        raise FileNotFoundError(f"Case note not found: {note_path.name}")

    note = note_path.read_text(encoding="utf-8")
    print(f"[2] Read case note: {note_name}")

    # 2. Search readable strings for the embedded archive clue.
    strings_result = subprocess.run(
        ["strings", str(image)],
        capture_output=True,
        text=True,
        check=True,
    )

    if "evidence_bundle.txt" not in strings_result.stdout:
        raise ValueError("Embedded evidence filename not found using strings.")

    print("[3] strings identified evidence_bundle.txt")

    # 3. Locate the embedded ZIP archive.
    data = image.read_bytes()
    zip_offset = data.find(b"PK\x03\x04")

    if zip_offset < 0:
        raise ValueError("Embedded ZIP archive not found.")

    print(f"[4] ZIP archive signature found at offset {zip_offset}")

    # 4. Open the embedded archive and recover the flag.
    with zipfile.ZipFile(BytesIO(data[zip_offset:])) as archive:
        member = "evidence_bundle.txt"

        if member not in archive.namelist():
            raise ValueError("Evidence text file missing from embedded ZIP.")

        recovered = archive.read(member).decode("utf-8")

    flag_match = re.search(
        r"CVCTF\{[A-Za-z0-9_!-]+\}",
        recovered,
    )

    if not flag_match:
        raise ValueError("Flag not found in recovered evidence.")

    flag = flag_match.group(0)
    print(f"[5] Recovered flag: {flag}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <evidence-directory>")
        sys.exit(2)

    try:
        solve(sys.argv[1])
    except (OSError, ValueError, subprocess.SubprocessError, zipfile.BadZipFile) as error:
        print(f"Solver error: {error}", file=sys.stderr)
        sys.exit(1)
