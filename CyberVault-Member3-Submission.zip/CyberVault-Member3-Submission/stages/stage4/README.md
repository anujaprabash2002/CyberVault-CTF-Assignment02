# Stage 4 — Evidence Under Investigation

- **Domain:** Digital Forensics
- **Difficulty:** Moderate
- **Case ID:** CV-204
- **Points:** 250

## Scenario
An analyst recovered a suspicious JPEG image from an employee workstation during a simulated security incident. The image may contain concealed evidence relevant to the investigation.

## Objective
Follow the forensic clues, identify the embedded archive, extract the evidence, and recover the CyberVault flag.

## Intended Investigation
1. Use ExifTool to inspect the metadata of `evidence/IMG_204.jpg`.
2. Follow the metadata clue to `evidence/case_note.txt`.
3. Use `strings` to search the JPEG for readable clues about embedded files.
4. Use Binwalk to identify the embedded ZIP archive and its byte offset.
5. Extract the embedded ZIP archive.
6. Inspect `evidence_bundle.txt` and submit the recovered flag to CTFd.

## Tools
- ExifTool
- `cat` or `less`
- `strings`
- Binwalk
- `dd` or a compatible archive extraction method
- `unzip`

## Hints
1. Begin with the JPEG metadata.
2. The User Comment field points to another piece of evidence.
3. Search the image for readable strings that mention an embedded file.
4. Binwalk can identify embedded archives and their offsets.
5. Extract the ZIP data and inspect the recovered text file.

## Reset
Run `./reset.sh` from this directory to restore the challenge evidence from `baseline/`.

## Flag
The flag is stored in the embedded evidence bundle. Investigators should recover it through the intended forensic workflow rather than guessing it.
