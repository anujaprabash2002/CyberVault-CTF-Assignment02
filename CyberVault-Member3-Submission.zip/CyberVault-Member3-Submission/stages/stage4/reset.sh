#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

cp baseline/IMG_204.jpg evidence/IMG_204.jpg
cp baseline/case_note.txt evidence/case_note.txt

echo "Stage 4 evidence restored to baseline."
