from PIL import Image, ImageDraw
import piexif

image = Image.new("RGB", (1000, 600), (28, 35, 45))
draw = ImageDraw.Draw(image)

draw.rectangle((40, 40, 960, 560), outline=(90, 160, 190), width=4)
draw.text((70, 80), "CYBERVAULT INCIDENT EVIDENCE", fill=(220, 235, 245))
draw.text((70, 140), "CASE: CV-204", fill=(220, 235, 245))
draw.text((70, 190), "Recovered from an employee workstation", fill=(180, 200, 215))
draw.text((70, 250), "Evidence item: IMG_204.jpg", fill=(180, 200, 215))
draw.text((70, 480), "FICTIONAL TRAINING EVIDENCE", fill=(240, 170, 90))

exif_dict = {
    "0th": {},
    "Exif": {
        piexif.ExifIFD.UserComment:
        b"ASCII\x00\x00\x00The incident note is stored in case_note.txt"
    },
    "GPS": {},
    "1st": {},
    "thumbnail": None
}

image.save("IMG_204.jpg", "JPEG", quality=90,
           exif=piexif.dump(exif_dict))

print("Created IMG_204.jpg")
