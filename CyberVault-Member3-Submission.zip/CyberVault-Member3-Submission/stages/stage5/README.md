# Stage 5 — Trace the Intrusion
- **Category:** Network Forensics
- **Difficulty:** Intermediate
- **Points:** 300
- **Flag format:** `CVCTF{...}`
## Scenario
The CyberVault security team detected suspicious activity between an employee workstation and an internal training server. A packet capture was preserved for investigation.

## Objective
Analyze the supplied PCAP to determine:
1. Which client initiated the suspicious activity.
2. Which server and service were targeted.
3. Which HTTP request appears suspicious.
4. How to recover the incident token from the server response.
5. The recovered CVCTF flag.
6. Recover the expected flag: `CVCTF{network_trace_05}`.

## Evidence
- `intrusion.pcap` — packet capture supplied to players.

## Suggested tools
- Wireshark
- TShark
- A Base64 decoder

## Suggested investigation
1. Identify the communicating hosts and HTTP traffic.
2. Find the suspicious `POST /admin/login` request.
3. Inspect the corresponding server response and incident reference `CV-505`.
4. Locate the Base64-encoded recovered token.
5. Decode the token and validate the recovered flag.
6. Submit the flag to the CTF platform when available.

## Hints
Progressive hints are maintained in `hints.txt`. The administrator should provide them in order when players need assistance.

## Administrator files
- `admin/answer-key.txt` — expected findings and flag.
- `admin/solve_stage5.py` — reference solver.
- `baseline/intrusion.pcap` — reset copy.

## Reset
Run `bash reset.sh` to restore the evidence PCAP from `baseline/`.

## Lab note
This is a synthetic training capture generated for the CyberVault CTF assignment. It does not represent a real incident.
