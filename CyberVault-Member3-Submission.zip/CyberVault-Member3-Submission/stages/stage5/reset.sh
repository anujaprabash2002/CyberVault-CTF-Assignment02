#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if [[ ! -f baseline/intrusion.pcap ]]; then
    echo "Error: baseline PCAP not found."
    exit 1
fi

cp baseline/intrusion.pcap evidence/intrusion.pcap

echo "Stage 5 evidence restored to baseline."
