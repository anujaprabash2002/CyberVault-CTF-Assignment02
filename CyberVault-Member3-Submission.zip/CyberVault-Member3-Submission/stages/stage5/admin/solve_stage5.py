#!/usr/bin/env python3

import base64
import re
import subprocess
import sys
from pathlib import Path


def solve(pcap_path):
    pcap_path = Path(pcap_path)

    if not pcap_path.is_file():
        raise FileNotFoundError(f"PCAP file not found: {pcap_path}")

    result = subprocess.run(
        [
            "tshark", "-r", str(pcap_path),
            "-Y", "http",
            "-T", "fields",
            "-e", "http.file_data",
            "-e", "tcp.payload",
        ],
        capture_output=True,
        text=True,
        check=True,
    )

    # Reassemble the packet payloads for this small synthetic capture.
    payloads = []
    for line in result.stdout.splitlines():
        for field in line.split("\t"):
            if field.strip():
                try:
                    payloads.append(
                        bytes.fromhex(field.strip().replace(":", "")).decode(
                            "utf-8", errors="replace"
                        )
                    )
                except ValueError:
                    payloads.append(field)

    combined = "\n".join(payloads)

    # Also inspect raw TCP payloads if TShark's HTTP fields are unavailable.
    if "Base64" not in combined:
        fallback = subprocess.run(
            [
                "tshark", "-r", str(pcap_path),
                "-Y", "tcp",
                "-T", "fields", "-e", "tcp.payload",
            ],
            capture_output=True,
            text=True,
            check=True,
        )
        decoded_payloads = []
        for value in fallback.stdout.splitlines():
            value = value.strip().replace(":", "")
            if value:
                try:
                    decoded_payloads.append(
                        bytes.fromhex(value).decode("utf-8", errors="replace")
                    )
                except ValueError:
                    continue
        combined = "\n".join(decoded_payloads)

    if "CV-505" not in combined:
        raise ValueError("Incident reference CV-505 was not found.")

    match = re.search(
        r"Recovered token \(Base64\):\s*([A-Za-z0-9+/]+={0,2})",
        combined,
    )
    if not match:
        raise ValueError("Base64 token was not found in the capture.")

    token = base64.b64decode(match.group(1), validate=True).decode("utf-8")
    if not re.fullmatch(r"CVCTF\{[A-Za-z0-9_!-]+\}", token):
        raise ValueError("Decoded token is not in the expected flag format.")

    print(f"[1] Investigated PCAP: {pcap_path.name}")
    print("[2] Found incident reference: CV-505")
    print("[3] Located Base64-encoded token in HTTP traffic")
    print(f"[4] Decoded flag: {token}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <player-pcap-file>")
        sys.exit(2)

    try:
        solve(sys.argv[1])
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print(f"Solver error: {error}", file=sys.stderr)
        sys.exit(1)
