#!/usr/bin/env python3

import base64
from pathlib import Path
from scapy.all import Ether, IP, TCP, Raw, wrpcap

OUTPUT = Path(__file__).parent / "intrusion.pcap"
packets = []

client = "192.168.56.20"
server = "192.168.56.10"
flag = "CVCTF{network_trace_05}"
encoded_flag = base64.b64encode(flag.encode()).decode()


def add_http_packet(src, dst, sport, dport, payload, seq=1000):
    packet = (
        Ether()
        / IP(src=src, dst=dst)
        / TCP(sport=sport, dport=dport, seq=seq, flags="PA")
        / Raw(load=payload.encode())
    )
    packets.append(packet)


# Ordinary web traffic: background requests and responses.
for i, page in enumerate(
    ["index.html", "about.html", "style.css", "logo.png",
     "help.html", "status", "contact.html", "robots.txt"]
):
    port = 52000 + i
    add_http_packet(
        client, server, port, 80,
        f"GET /{page} HTTP/1.1\r\nHost: training-server\r\n\r\n",
        seq=1000 + i * 100,
    )
    add_http_packet(
        server, client, 80, port,
        "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n"
        f"Resource served: {page}\n",
        seq=2000 + i * 100,
    )

# Simulated suspicious administrator login.
add_http_packet(
    client, server, 51515, 80,
    "POST /admin/login HTTP/1.1\r\n"
    "Host: training-server\r\n"
    "Content-Type: application/x-www-form-urlencoded\r\n"
    "Content-Length: 35\r\n\r\n"
    "username=admin&password=training123",
)

# Server response contains an encoded token, not the plaintext flag.
add_http_packet(
    server, client, 80, 51515,
    "HTTP/1.1 200 OK\r\n"
    "Content-Type: text/plain\r\n"
    "X-Incident-Reference: CV-505\r\n\r\n"
    "Authentication event recorded.\n"
    "Recovered token (Base64): " + encoded_flag + "\n",
)

wrpcap(str(OUTPUT), packets)

print(f"Created {OUTPUT}")
print(f"Packets written: {len(packets)}")
print("The incident token is Base64-encoded in the HTTP response.")
