# Individual Contribution — Member 3

Student: Ediriweera D.R
Registration number: IT24100338
Role: Challenge Design B — Stages 4, 5, and 6

## Work included
1. Stage 4: digital-forensics evidence, metadata clue, evidence references,
   Base64 recovery, reset support, hints, and Python solver.
2. Stage 5: synthetic PCAP generation, HTTP investigation scenario, encoded
   incident token, progressive hints, reset support, and TShark/Python solver.
3. Stage 6: simulated SSH/server-forensics evidence, login correlation,
   encoded incident token, progressive hints, reset support, and Python solver.
4. Documentation: README files, administrator answer keys, player evidence ZIPs,
   and deployment instructions.
5. Validation: Python syntax checks, ZIP integrity checks, and local solver
   tests.

## Evidence limitations
Test logs in test-logs record the checks run during package preparation.
Repository history is included only if an existing Git repository was found.
Do not interpret a newly created package or filesystem timestamps as proof of
earlier commits. Live CTFd submissions remain to be verified.
