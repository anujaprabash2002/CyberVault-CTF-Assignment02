# CyberVault CTF — Member 3 Submission

## Contents
- stages/stage4: digital-forensics challenge, evidence, baseline, reset script,
  hints, admin answer key, solver, and player ZIP.
- stages/stage5: synthetic PCAP challenge, generator, baseline, reset script,
  hints, admin answer key, solver, and player ZIP.
- stages/stage6: simulated Linux server-forensics challenge, baseline, reset
  script, hints, admin answer key, solver, and player ZIP.
- deployment: Docker Compose project and instructions for deploying CTFd and
  creating the three challenges.
- contribution: contribution summary, available repository history, and test
  logs.

## Deploy
Follow deployment/README.md and deployment/CHALLENGE-SETUP.md.

## Reset
Use each stage's reset.sh to restore its evidence from baseline/.

## Scope and validation
The stage solvers and evidence packages have been tested locally. A successful
live CTFd flag submission must be verified separately after CTFd is deployed
and the three challenges are created. The Stage 6 server logs are simulated
training evidence, not logs from a real compromised server.

No VM image is included; the deployment option is Docker Compose.
