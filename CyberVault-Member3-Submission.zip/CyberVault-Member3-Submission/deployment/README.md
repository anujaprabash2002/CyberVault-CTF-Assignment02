# CyberVault CTF — Docker Compose Deployment

## Requirements
- Docker Engine and the Docker Compose plugin
- Internet access to pull the required container images
- Approximately 2 GB RAM or more available for the deployment

## Configure
1. Copy `.env.example` to `.env`.
2. Generate three separate random hexadecimal secrets on the deployment host,
   for example with `openssl rand -hex 32`.
3. Replace the three placeholder values in `.env`.
4. Keep `.env` private; do not submit real passwords or secret keys.

## Start
From this directory:

    docker compose up -d

Check the services:

    docker compose ps
    docker compose logs --tail=100 ctfd

Open http://127.0.0.1:8000 and complete CTFd's initial administrator setup.
Follow CHALLENGE-SETUP.md to create the three challenges, attach their player
ZIPs, add their flags, and enter their hints.

The Compose project starts CTFd and its database/cache services. Challenge
records must still be created in the CTFd interface using the included setup
guide; they are not automatically imported by this Compose file.

## Stop
    docker compose down

This stops the services but preserves the database volume and uploaded data.

## Reset challenge evidence
On the host, restore a stage's evidence from its baseline:

    bash ../stages/stage4/reset.sh
    bash ../stages/stage5/reset.sh
    bash ../stages/stage6/reset.sh

These commands reset evidence files, not CTFd accounts, scores, or database
records.

## Full platform reset — destructive
To remove the CTFd database volume as well as stop the services:

    docker compose down -v

This deletes the stored CTFd database. Back up anything needed before doing it.

## Network note
The default port binding is localhost-only. For access from another computer,
change the port binding deliberately and configure the host firewall before
making the service available on a network. Do not expose an unconfigured CTF
instance to the public internet.
