# CyberVault CTF Challenge Setup

After launching CTFd, complete its first-run setup and create the administrator account. Create the three challenges below using the CTFd administration interface.

Attach only the corresponding player ZIP to each challenge. Copy the progressive hints from each stage's `hints.txt` into the challenge hint settings. Never upload admin answer keys or solver scripts as player attachments.

## Stage 4 — Digital Forensics

* **Category:** Digital Forensics
* **Suggested value:** 250 points
* **Attachment:** `stages/stage4/stage4-player-evidence.zip`
* **Flag:** `CVCTF{forensic_evidence_04}`
* **Hints:** `stages/stage4/hints.txt`
* **Objective:** Investigate the image metadata, follow the evidence clues, locate the embedded ZIP archive, and recover the flag.

## Stage 5 — Trace the Intrusion

* **Category:** Network Forensics
* **Suggested value:** 300 points
* **Attachment:** `stages/stage5/stage5-player-evidence.zip`
* **Flag:** `CVCTF{network_trace_05}`
* **Hints:** `stages/stage5/hints.txt`
* **Objective:** Analyze the synthetic PCAP, identify the suspicious HTTP request and incident reference CV-505, and decode the recovered token.

## Stage 6 — The Compromised Server

* **Category:** Linux Server Forensics
* **Suggested value:** 400 points
* **Attachment:** `stages/stage6/stage6-player-evidence.zip`
* **Flag:** `CVCTF{compromised_server_06}`
* **Hints:** `stages/stage6/hints.txt`
* **Objective:** Investigate SSH authentication activity, correlate suspicious access with deployment and service evidence, and recover the incident flag.

**Stage 6 deployment requirement:** The player ZIP contains supplementary simulated log evidence. The designated Ubuntu Server VM, authorized SSH access, and suspicious service must be configured and tested separately before advertising the challenge as a live server investigation.

## CTFd configuration

1. Create each challenge using the title and category above.
2. Set the corresponding point value.
3. Upload only the listed player ZIP.
4. Add the matching flag as a normal exact-match flag.
5. Add hints in the order listed in the stage's `hints.txt`.
6. Save each challenge and test flag submission using the intended player workflow.

Do not expose this administrator setup document, answer keys, or solver scripts to players.

## Verification status

The stage reset scripts and local reference solvers have been tested. CTFd challenge creation, live flag submissions, and Stage 6 Ubuntu Server VM deployment must be verified separately.
